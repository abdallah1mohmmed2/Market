from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'lib/features/app.dart').read_text()
CALC = (ROOT / 'lib/domain/accounting/calculations.dart').read_text()
REPORT = (ROOT / 'lib/services/report_service.dart').read_text()
REPO = (ROOT / 'lib/data/repositories/repositories.dart').read_text()

checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

check('central balance label exists', "static String balanceLabel(int balance)" in CALC)
check('positive means عليه', "'عليه ${balance.abs()} ريال'" in CALC)
check('negative means له', "'له ${balance.abs()} ريال'" in CALC)
check('zero means متوازن', "'متوازن'" in CALC)
check('dashboard no ambiguous المتبقي label', "_badge('المتبقي'" not in APP and "'المتبقي',\n                money(remaining)" not in APP)
check('new irrigation uses حالة الرصيد', "'حالة الرصيد': c.totalAmount - paidValue" in APP)
check('new irrigation displays حالة الرصيد', "Metric(\n                  'حالة الرصيد'" in APP)
check('new irrigation displays المدفوع', "Metric('المدفوع'" in APP)
check('worker list displays direction', "balanceLabel((x['balance'] as num?)?.round() ?? 0)" in APP)
check('partner list displays direction', APP.count("balanceLabel((x['balance'] as num?)?.round() ?? 0)") >= 2)
check('report balance header semantic', "'balance':'حالة الرصيد'" in REPORT)
check('report remaining header semantic', "'remaining':'حالة الرصيد'" in REPORT)
check('report formats balance as له/عليه', "if (key == 'balance' || key == 'remaining')" in REPORT)
check('beneficiary statement carries running balance', "'balance': running" in REPO)
check('worker report has running balance', "worker_transactions h WHERE h.worker_id=wt.worker_id" in REPO)
check('partner report has running balance', "partner_transactions h WHERE h.partner_id=pt.partner_id" in REPO)
check('worker list query has balance', 'FROM worker_transactions wt WHERE wt.worker_id=w.id' in REPO)
check('partner list query has balance', 'FROM partner_transactions pt WHERE pt.partner_id=p.id' in REPO)
check('journal retains debit credit', "'journal': ['date','description','account_code','account_name','debit','credit']" in REPORT)
check('ledger retains debit credit', "'ledger': ['date','description','account_code','account_name','debit','credit']" in REPORT)
check('no user-facing ambiguous المتبقي in app', 'المتبقي' not in APP)
check('no report-facing ambiguous المتبقي', "'المتبقي'" not in REPORT)

failed = [n for n, ok in checks if not ok]
for n, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' - ' + n)
print(f'Accounting terms acceptance: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    raise SystemExit(1)
