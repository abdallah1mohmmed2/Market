import '../../core/app_clock.dart';
import '../../core/app_prefs.dart';
import 'package:sqflite/sqflite.dart';
import '../local/database.dart';
import '../local/queue_rotation.dart';
import '../../domain/accounting/accounting_service.dart';
import '../../domain/accounting/balance_sql.dart';
import '../../domain/accounting/calculations.dart';

class StationRepository {
  final AppDatabase db;
  late final AccountingService accounting;
  StationRepository([AppDatabase? database])
    : db = database ?? AppDatabase.instance {
    accounting = AccountingService(db);
  }

  Future<List<Map<String, Object?>>> beneficiaries([String q = '']) => db.query(
    '''SELECT b.*,
    (${BalanceSql.beneficiary('b')}) balance
    FROM beneficiaries b WHERE b.status='active' AND (b.name LIKE ? OR COALESCE(b.phone,'') LIKE ? OR COALESCE(b.jerba_number,'') LIKE ? OR COALESCE(b.location,'') LIKE ?) ORDER BY b.name''',
    args: ['%$q%', '%$q%', '%$q%', '%$q%'],
  );

  Future<int> createBeneficiary({
    required String name,
    String? phone,
    String? address,
    String? location,
    String? jerba,
    String? area,
    bool needy = false,
    int opening = 0,
    int carried = 0,
    double openingDiesel = 0,
    String? notes,
    int? userId,
  }) async {
    if (name.trim().isEmpty) throw ArgumentError('اسم المستفيد مطلوب');
    final now = AppClock.now().toIso8601String();
    // الإدخال والقيود الافتتاحية في معاملة واحدة: لا يُحفظ رصيد بلا أثر في الأستاذ.
    final id = await db.transaction((tx) async {
      final newId = await tx.insert('beneficiaries', {
        'name': name.trim(),
        'phone': phone,
        'address': address,
        'location': location,
        'jerba_number': jerba,
        'area': area,
        'is_needy': needy ? 1 : 0,
        'opening_balance': opening,
        'carried_balance': carried,
        'opening_diesel_liters': openingDiesel,
        'notes': notes,
        'status': 'active',
        'created_at': now,
        'updated_at': now,
      });
      await accounting.postBeneficiaryBalanceDeltaTx(
        tx,
        newId,
        name.trim(),
        newOpening: opening,
        newCarried: carried,
        userId: userId,
      );
      return newId;
    });
    if (openingDiesel > 0)
      await accounting.addDieselMovement(
        beneficiaryId: id,
        kind: 'opening_balance',
        liters: openingDiesel,
        unitPrice: 0,
        date: AppClock.now(),
        userId: userId,
        notes: 'رصيد ديزل افتتاحي',
      );
    await db.audit(
      userId: userId,
      operation: 'create',
      table: 'beneficiaries',
      recordId: id,
      newValues: {'name': name},
    );
    return id;
  }

  static const Set<String> _beneficiaryEditable = {
    'name',
    'phone',
    'address',
    'location',
    'jerba_number',
    'area',
    'is_needy',
    'notes',
    'opening_balance',
    'carried_balance',
  };

  /// تعديل بيانات المستفيد. الأعمدة المسموحة فقط؛ وأي تغيير في الرصيد الافتتاحي أو المرحَّل
  /// يُقيَّد في الأستاذ بقيد فرق في نفس المعاملة (لا يُكتب الرقم مباشرةً دون قيد).
  Future<void> updateBeneficiary(
    int id,
    Map<String, Object?> values,
    int? userId,
  ) async {
    final unknown = values.keys.where((k) => k != 'updated_at' && !_beneficiaryEditable.contains(k));
    if (unknown.isNotEmpty) {
      throw ArgumentError('حقول غير قابلة للتعديل: ${unknown.join('، ')}');
    }
    if (values.containsKey('name') && '${values['name']}'.trim().isEmpty) {
      throw ArgumentError('اسم المستفيد مطلوب');
    }
    final rows = await db.query('SELECT * FROM beneficiaries WHERE id=?', args: [id]);
    if (rows.isEmpty) throw StateError('المستفيد غير موجود');
    final old = rows.first;
    final newValues = {...values, 'updated_at': AppClock.now().toIso8601String()};
    int asInt(Object? v) => (v as num?)?.round() ?? 0;
    final oldOpening = asInt(old['opening_balance']);
    final oldCarried = asInt(old['carried_balance']);
    final newOpening = values.containsKey('opening_balance') ? asInt(values['opening_balance']) : oldOpening;
    final newCarried = values.containsKey('carried_balance') ? asInt(values['carried_balance']) : oldCarried;
    await db.transaction((tx) async {
      await tx.update('beneficiaries', newValues, where: 'id=?', whereArgs: [id]);
      await accounting.postBeneficiaryBalanceDeltaTx(
        tx,
        id,
        '${newValues['name'] ?? old['name']}',
        oldOpening: oldOpening,
        newOpening: newOpening,
        oldCarried: oldCarried,
        newCarried: newCarried,
        userId: userId,
      );
      await db.auditTx(
        tx,
        userId: userId,
        operation: 'update',
        table: 'beneficiaries',
        recordId: id,
        oldValues: old,
        newValues: newValues,
      );
    });
  }

  /// الحذف المنطقي للمستفيد مرفوض ما دام رصيده غير صفر (عليه أو له) أو لديه جلسة قيد التشغيل؛
  /// وإلا يخرج من «حالة الأرصدة» و«المديونيات» وتبقى سقاياه في «المستحق» و«المدفوع».
  Future<void> deleteBeneficiary(int id, int? userId, String reason) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب الحذف المنطقي مطلوب');
    final rows = await db.query('SELECT * FROM beneficiaries WHERE id=?', args: [id]);
    if (rows.isEmpty) throw StateError('المستفيد غير موجود');
    final old = rows.first;
    final bal = (await accounting.beneficiaryBalance(id))['balance'] ?? 0;
    if (bal != 0) {
      throw StateError(
        'لا يمكن حذف مستفيد رصيده ${AccountingCalculations.balanceLabel(bal)}؛ سوِّ الرصيد أولًا ثم احذفه',
      );
    }
    final running = await db.query(
      "SELECT 1 FROM irrigation_sessions WHERE beneficiary_id=? AND status='running' LIMIT 1",
      args: [id],
    );
    if (running.isNotEmpty) {
      throw StateError('لا يمكن حذف مستفيد لديه جلسة سقي قيد التشغيل');
    }
    final now = AppClock.now().toIso8601String();
    await db.transaction((tx) async {
      await tx.update(
        'beneficiaries',
        {'status': 'deleted', 'updated_at': now},
        where: 'id=?',
        whereArgs: [id],
      );
      // أدواره وحجوزاته المعلّقة لا معنى لها بعد حذفه.
      await tx.update(
        'queue_entries',
        {'status': 'cancelled', 'updated_at': now, 'skip_reason': 'حذف المستفيد'},
        where: "beneficiary_id=? AND status IN ('waiting','postponed')",
        whereArgs: [id],
      );
      await tx.update(
        'booking_requests',
        {'status': 'cancelled', 'cancel_reason': 'حذف المستفيد', 'reviewed_at': now},
        where: "beneficiary_id=? AND status IN ('new','under_review','scheduled','accepted','notified')",
        whereArgs: [id],
      );
      await db.auditTx(
        tx,
        userId: userId,
        operation: 'logical_delete',
        table: 'beneficiaries',
        recordId: id,
        oldValues: old,
        reason: reason,
      );
    });
  }

  Future<Map<String, Object?>> beneficiaryDetails(int id) async {
    final b = (await db.query(
      'SELECT * FROM beneficiaries WHERE id=?',
      args: [id],
    )).first;
    return {...b, 'balance': await accounting.beneficiaryBalance(id)};
  }

  /// كشف حساب المستفيد. الرصيد الجاري يطابق [AccountingService.beneficiaryBalance]:
  /// الافتتاحي + السقايات + سلف الديزل − الدفعات − تسليم الديزل (إن كان ائتمانًا ماليًا).
  Future<List<Map<String, Object?>>> beneficiaryStatement(
    int id, {
    DateTime? from,
    DateTime? to,
  }) async {
    final baseRows = await db.query(
      'SELECT opening_balance,carried_balance FROM beneficiaries WHERE id=?',
      args: [id],
    );
    if (baseRows.isEmpty) return <Map<String, Object?>>[];
    var running = ((baseRows.first['opening_balance'] as num?)?.round() ?? 0) +
        ((baseRows.first['carried_balance'] as num?)?.round() ?? 0);
    final creditDelivery =
        (await settings())['diesel_delivery_financial_credit'] == 'true';
    final events = await db.query(
      "SELECT i.id,i.date,i.start_datetime,i.end_datetime,i.system_type,i.minutes,i.cloud_minutes,i.chargeable_minutes,i.total_amount,i.paid_amount,'s' type,i.total_amount debit,0 credit,'سقاية' description FROM irrigations i WHERE i.beneficiary_id=? AND i.status!='cancelled' "
      "UNION ALL SELECT p.id,p.date,p.date,p.date,'payment',0,0,0,0,-p.amount,'p',0,p.amount,'دفعة' FROM payments p WHERE p.beneficiary_id=? AND p.status='posted' "
      "UNION ALL SELECT d.id,d.date,d.date,d.date,'diesel_advance',0,0,0,0,0,'a',d.amount,0,'سلفة ديزل' FROM diesel_movements d WHERE d.beneficiary_id=? AND d.kind='advance' AND d.irrigation_id IS NULL "
      "${creditDelivery ? "UNION ALL SELECT d.id,d.date,d.date,d.date,'diesel_delivery',0,0,0,0,0,'d',0,d.amount,'تسليم ديزل' FROM diesel_movements d WHERE d.beneficiary_id=? AND d.kind='delivery' " : ''}"
      "ORDER BY date,id",
      args: [id, id, id, if (creditDelivery) id],
    );
    final result = <Map<String, Object?>>[];
    for (final raw in events) {
      final debit = (raw['debit'] as num?)?.round() ?? 0;
      final credit = (raw['credit'] as num?)?.round() ?? 0;
      running += debit - credit;
      final row = {...raw, 'balance': running};
      final date = DateTime.tryParse('${raw['date'] ?? ''}');
      if (from != null && date != null && date.isBefore(from)) continue;
      if (to != null && date != null && date.isAfter(to)) continue;
      result.add(row);
    }
    return result;
  }

  Future<List<Map<String, Object?>>> wateringTotals({
    DateTime? from,
    DateTime? to,
    int? beneficiaryId,
    String? systemType,
  }) async {
    final args = <Object?>[];
    var w = "i.status!='cancelled'";
    if (from != null) {
      w += ' AND i.start_datetime>=?';
      args.add(from.toIso8601String());
    }
    if (to != null) {
      w += ' AND i.start_datetime<=?';
      args.add(to.toIso8601String());
    }
    if (beneficiaryId != null) {
      w += ' AND i.beneficiary_id=?';
      args.add(beneficiaryId);
    }
    if (systemType != null && systemType != 'all') {
      w += ' AND i.system_type=?';
      args.add(systemType);
    }
    return db.query(
      "SELECT substr(i.date,1,10) day,substr(i.date,1,7) month,substr(i.date,1,4) year,COALESCE(SUM(i.minutes),0) minutes,ROUND(COALESCE(SUM(i.minutes),0)/60.0,2) hours,COUNT(*) sessions,COALESCE(SUM(i.total_amount),0) total FROM irrigations i WHERE $w GROUP BY day,month,year ORDER BY day DESC",
      args: args,
    );
  }

  Future<List<Map<String, Object?>>> cloudPeriods(int irrigationId) async =>
      db.query('cloud_periods', where: 'irrigation_id=?', args: [irrigationId], orderBy: 'start_datetime');

  Future<List<Map<String, Object?>>> irrigations({
    DateTime? from,
    DateTime? to,
    String? systemType,
    int? beneficiaryId,
  }) async {
    final args = <Object?>[];
    var w = "i.status!='cancelled'";
    if (from != null) {
      w += ' AND i.start_datetime>=?';
      args.add(from.toIso8601String());
    }
    if (to != null) {
      w += ' AND i.start_datetime<=?';
      args.add(to.toIso8601String());
    }
    if (systemType != null) {
      w += ' AND i.system_type=?';
      args.add(systemType);
    }
    if (beneficiaryId != null) {
      w += ' AND i.beneficiary_id=?';
      args.add(beneficiaryId);
    }
    return db.query(
      'SELECT i.*,COALESCE(b.name,w.name,pt.name) beneficiary_name,p.name pump_name FROM irrigations i LEFT JOIN beneficiaries b ON b.id=i.beneficiary_id LEFT JOIN workers w ON w.id=i.worker_id LEFT JOIN partners pt ON pt.id=i.partner_id JOIN pumps p ON p.id=i.pump_id WHERE $w ORDER BY i.start_datetime DESC',
      args: args,
    );
  }

  Future<List<Map<String, Object?>>> queue() => db.query(
    "SELECT q.*,b.name beneficiary_name,b.phone FROM queue_entries q JOIN beneficiaries b ON b.id=q.beneficiary_id WHERE q.status IN ('waiting','postponed') ORDER BY q.position,q.cycle_number,q.created_at",
  );
  Future<int> enqueue(int beneficiaryId, {int? position, int? userId}) async {
    final rows = await db.query(
      "SELECT COALESCE(MAX(position),0)+1 n FROM queue_entries WHERE status IN ('waiting','postponed')",
    );
    final pos = position ?? ((rows.first['n'] as num?)?.toInt() ?? 1);
    final now = AppClock.now().toIso8601String();
    final id = await db.insert('queue_entries', {
      'beneficiary_id': beneficiaryId,
      'position': pos,
      'cycle_number': 1,
      'status': 'waiting',
      'created_at': now,
      'updated_at': now,
    });
    await db.audit(
      userId: userId,
      operation: 'enqueue',
      table: 'queue_entries',
      recordId: id,
      newValues: {'beneficiary_id': beneficiaryId, 'position': pos},
    );
    return id;
  }

  /// معالجة غياب/تأجيل مستفيد في الدور حسب إعداد «سياسة الغياب»:
  /// - `postpone`: ينتقل لآخر الدور بحالة «مؤجل».
  /// - `keep_order`: يحتفظ بمكانه في الدور (يُسجَّل التأجيل والسبب فقط).
  /// - `cancel`: يُزال من الدور.
  Future<void> postponeQueue(int id, String reason, {int? userId}) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب التأجيل مطلوب');
    var policy = (await settings())['absence_policy'] ?? 'keep_order';
    if (policy == 'keep') policy = 'keep_order';
    if (!const {'postpone', 'keep_order', 'cancel'}.contains(policy)) policy = 'keep_order';
    await db.transaction((tx) async {
      final rows = await tx.query(
        'queue_entries',
        where: 'id=?',
        whereArgs: [id],
        limit: 1,
      );
      if (rows.isEmpty) throw StateError('الدور غير موجود');
      final q = rows.first;
      if (!const {'waiting', 'postponed'}.contains('${q['status']}')) {
        throw StateError('لا يمكن تأجيل دور حالته ليست «منتظر» أو «مؤجل»');
      }
      final now = AppClock.now().toIso8601String();
      final count = ((q['postponed_count'] as num?)?.toInt() ?? 0) + 1;
      if (policy == 'postpone') {
        final max =
            (await tx.rawQuery(
                  "SELECT COALESCE(MAX(position),0)+1 n FROM queue_entries WHERE status IN ('waiting','postponed') AND id<>?",
                  [id],
                )).first['n']
                as num;
        await tx.update(
          'queue_entries',
          {
            'status': 'postponed',
            'position': max.toInt(),
            'postponed_count': count,
            'skip_reason': reason,
            'updated_at': now,
          },
          where: 'id=?',
          whereArgs: [id],
        );
      } else if (policy == 'cancel') {
        await tx.update(
          'queue_entries',
          {
            'status': 'cancelled',
            'postponed_count': count,
            'skip_reason': reason,
            'updated_at': now,
          },
          where: 'id=?',
          whereArgs: [id],
        );
      } else {
        await tx.update(
          'queue_entries',
          {'postponed_count': count, 'skip_reason': reason, 'updated_at': now},
          where: 'id=?',
          whereArgs: [id],
        );
      }
      await db.auditTx(
        tx,
        userId: userId,
        operation: 'postpone:$policy',
        table: 'queue_entries',
        recordId: id,
        oldValues: q,
        reason: reason,
      );
    });
  }

  Future<void> serveSpecific(int id, int userId, String reason) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب تجاوز الدور مطلوب');
    await db.update(
      'queue_entries',
      {
        'position': 0,
        'status': 'waiting',
        'skip_reason': reason,
        'updated_at': AppClock.now().toIso8601String(),
      },
      'id=?',
      [id],
    );
    await db.audit(
      userId: userId,
      operation: 'queue_override',
      table: 'queue_entries',
      recordId: id,
      reason: reason,
    );
  }

  /// إنهاء دور يدويًا (خُدم خارج النظام): في الطابور الدائري يعود لآخر الدور.
  Future<void> completeQueue(int id, {int? userId}) async {
    final old = (await db.query(
      'SELECT * FROM queue_entries WHERE id=?',
      args: [id],
    )).first;
    final circular = ((await settings())['queue_type'] ?? 'circular') == 'circular';
    if (circular) {
      await rotateCircularQueue(id);
    } else {
      await db.transaction(
        (tx) => completeQueueEntryTx(
          tx,
          id,
          AppClock.now().toIso8601String(),
          circular: false,
        ),
      );
    }
    await db.audit(
      userId: userId,
      operation: 'serve',
      table: 'queue_entries',
      recordId: id,
      oldValues: old,
    );
  }

  Future<void> rotateCircularQueue(int servedId) => db.transaction(
    (tx) => completeQueueEntryTx(
      tx,
      servedId,
      AppClock.now().toIso8601String(),
      circular: true,
    ),
  );

  Future<List<Map<String, Object?>>> bookings([String? status]) => db.query(
    "SELECT br.*,b.name beneficiary_name,b.phone FROM booking_requests br JOIN beneficiaries b ON b.id=br.beneficiary_id ${status == null ? '' : 'WHERE br.status=?'} ORDER BY br.created_at",
    args: status == null ? [] : [status],
  );
  Future<int> createBooking(
    int beneficiaryId,
    String notes, {
    int? userId,
  }) async {
    final now = AppClock.now().toIso8601String();
    final id = await db.insert('booking_requests', {
      'beneficiary_id': beneficiaryId,
      'created_at': now,
      'status': 'new',
      'notes': notes,
    });
    await db.audit(
      userId: userId,
      operation: 'booking_create',
      table: 'booking_requests',
      recordId: id,
      newValues: {'beneficiary_id': beneficiaryId, 'notes': notes},
    );
    return id;
  }

  Future<void> reviewBooking(
    int id, {
    required String status,
    DateTime? start,
    DateTime? end,
    int? reviewer,
    String? reason,
  }) async {
    final rows = await db.query(
      'SELECT * FROM booking_requests WHERE id=?',
      args: [id],
    );
    if (rows.isEmpty) throw StateError('الحجز غير موجود');
    final old = rows.first;
    // الحجز المكتمل أو الملغى ثابت؛ لا يُعاد فتحه من هنا.
    if (const {'completed', 'cancelled'}.contains('${old['status']}')) {
      throw StateError('لا يمكن تعديل حجز ${old['status'] == 'completed' ? 'مكتمل' : 'ملغى'}');
    }
    if (status == 'cancelled' && (reason ?? '').trim().isEmpty) {
      throw ArgumentError('سبب إلغاء الحجز مطلوب');
    }
    await db.update(
      'booking_requests',
      {
        'status': status,
        'scheduled_date': start?.toIso8601String().substring(0, 10),
        'scheduled_start': start?.toIso8601String(),
        'scheduled_end': end?.toIso8601String(),
        'reviewed_by': reviewer,
        'reviewed_at': AppClock.now().toIso8601String(),
        'cancel_reason': reason,
      },
      'id=?',
      [id],
    );
    await db.audit(
      userId: reviewer,
      operation: 'booking_update',
      table: 'booking_requests',
      recordId: id,
      oldValues: old,
      newValues: {
        'status': status,
        'scheduled_start': start?.toIso8601String(),
        'scheduled_end': end?.toIso8601String(),
      },
      reason: reason,
    );
    if ((status == 'scheduled' || status == 'accepted') &&
        old['beneficiary_id'] != null) {
      final dateText = start == null
          ? 'سيتم تحديد الموعد لاحقًا'
          : '${start.year}/${start.month.toString().padLeft(2, '0')}/${start.day.toString().padLeft(2, '0')} ${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')}';
      await notify(
        beneficiaryId: old['beneficiary_id'] as int,
        type: 'appointment',
        title: 'موعد السقي',
        body: 'تم تحديد موعد السقي: $dateText',
      );
    }
  }

  /// تعديل ملاحظات الحجز (لا يغيّر حالته).
  Future<void> updateBookingNotes(int id, String notes, {int? userId}) async {
    final rows = await db.query('SELECT * FROM booking_requests WHERE id=?', args: [id]);
    if (rows.isEmpty) throw StateError('الحجز غير موجود');
    if (const {'completed', 'cancelled'}.contains('${rows.first['status']}')) {
      throw StateError('لا يمكن تعديل حجز مكتمل أو ملغى');
    }
    await db.update('booking_requests', {'notes': notes}, 'id=?', [id]);
    await db.audit(
      userId: userId,
      operation: 'booking_update',
      table: 'booking_requests',
      recordId: id,
      oldValues: {'notes': rows.first['notes']},
      newValues: {'notes': notes},
    );
  }

  Future<List<Map<String, Object?>>> sessions() => db.query(
    'SELECT s.*,b.name beneficiary_name,p.name pump_name FROM irrigation_sessions s JOIN beneficiaries b ON b.id=s.beneficiary_id JOIN pumps p ON p.id=s.pump_id ORDER BY COALESCE(s.actual_start,s.planned_start) DESC',
  );
  Future<int> startSession({
    required int beneficiaryId,
    required int pumpId,
    int? queueId,
    int? bookingId,
  }) async {
    final set = await settings();
    final configuredPumpId = int.tryParse(set['selected_pump_id'] ?? '');
    if (configuredPumpId == null || configuredPumpId != pumpId)
      throw StateError('يجب استخدام المضخة المحددة في الإعدادات فقط');
    final active = await db.query(
      "SELECT id FROM irrigation_sessions WHERE pump_id=? AND status='running' LIMIT 1",
      args: [pumpId],
    );
    if (active.isNotEmpty) throw StateError('المضخة لديها جلسة سقي فعالة');
    if ((set['queue_type'] ?? 'circular') == 'booking') {
      if (bookingId == null)
        throw StateError('لا يمكن بدء جلسة عشوائية في وضع الحجز');
      final booking = await db.query(
        "SELECT * FROM booking_requests WHERE id=? AND beneficiary_id=?",
        args: [bookingId, beneficiaryId],
      );
      if (booking.isEmpty ||
          ![
            'scheduled',
            'accepted',
            'notified',
          ].contains('${booking.first['status']}'))
        throw StateError('الحجز غير مجدول أو لا يخص المستفيد المحدد');
    }
    if (queueId != null) {
      final q = await db.query(
        "SELECT * FROM queue_entries WHERE id=? AND beneficiary_id=? AND status IN ('waiting', 'postponed')",
        args: [queueId, beneficiaryId],
      );
      if (q.isEmpty) throw StateError('دور الطابور غير صالح للمستفيد المحدد');
    }
    final now = AppClock.now().toIso8601String();
    final stock = set['system_type'] == 'diesel' ? await accounting.dieselStock() : 0.0;
    return db.insert('irrigation_sessions', {
      'beneficiary_id': beneficiaryId,
      'queue_entry_id': queueId,
      'booking_id': bookingId,
      'pump_id': pumpId,
      'planned_start': now,
      'actual_start': now,
      'timer_started_at': now,
      'status': 'running',
      'diesel_before': stock,
    });
  }

  Future<int> stopSession(
    int sessionId, {
    int cloudMinutes = 0,
    int? userId,
  }) async {
    final s = (await db.query(
      'SELECT * FROM irrigation_sessions WHERE id=?',
      args: [sessionId],
    )).first;
    if (s['status'] != 'running') throw StateError('الجلسة ليست قيد التشغيل');
    final end = AppClock.now();
    final pumpId = s['pump_id'] as int;
    final p = (await db.query(
      'SELECT * FROM pumps WHERE id=?',
      args: [pumpId],
    )).first;
    final set = await settings();
    // لا نغيّر حالة الجلسة هنا: recordIrrigation تُنهيها داخل نفس المعاملة.
    // عند أي فشل (انتظار/تعارض/فترة مغلقة) تبقى الجلسة قيد التشغيل لإعادة المحاولة.
    final id = await accounting.recordIrrigation(
      stationId: p['station_id'] as int,
      pumpId: pumpId,
      beneficiaryId: s['beneficiary_id'] as int,
      start: DateTime.parse(s['actual_start'] as String),
      end: end,
      systemType: set['system_type'] ?? 'diesel',
      waterRate: int.tryParse(set['diesel_hourly_water_rate'] ?? '0') ?? 0,
      litersPerHour: double.tryParse(set['diesel_liters_per_hour'] ?? '0') ?? 0,
      dieselPrice: int.tryParse(set['diesel_price_per_liter'] ?? '0') ?? 0,
      solarRate: int.tryParse(set['solar_hourly_rate'] ?? '0') ?? 0,
      thirdRate: int.tryParse(set['third_type_hourly_rate'] ?? '0') ?? 0,
      cloudMinutes: cloudMinutes,
      paidAmount: 0,
      queueId: s['queue_entry_id'] as int?,
      bookingId: s['booking_id'] as int?,
      sessionId: sessionId,
      userId: userId,
    );
    return id;
  }

  Future<void> postponeSession(
    int sessionId,
    String reason, {
    int? userId,
  }) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب تأجيل الجلسة مطلوب');
    final cur = await db.query(
      'SELECT status FROM irrigation_sessions WHERE id=?',
      args: [sessionId],
    );
    if (cur.isEmpty) throw StateError('الجلسة غير موجودة');
    // لا يُؤجَّل إلا ما هو قيد التشغيل؛ الجلسة المكتملة أو المؤجلة سابقًا ثابتة.
    if (cur.first['status'] != 'running') {
      throw StateError('لا يمكن تأجيل جلسة حالتها ليست «قيد التشغيل»');
    }
    await db.update(
      'irrigation_sessions',
      {'status': 'postponed', 'postponement_reason': reason},
      'id=?',
      [sessionId],
    );
    await db.audit(
      userId: userId,
      operation: 'session_postpone',
      table: 'irrigation_sessions',
      recordId: sessionId,
      reason: reason,
    );
  }

  Future<Map<String, Object?>> dieselWarning() async {
    final set = await settings();
    final warning =
        double.tryParse(set['diesel_warning_percent'] ?? '20') ?? 20;
    final r = await db.query(
      "SELECT COALESCE(SUM(CASE WHEN kind IN ('receipt','opening_balance','correction') THEN liters WHEN kind IN ('delivery','consumption') THEN -liters ELSE 0 END),0) stock FROM diesel_movements",
    );
    final stock = (r.first['stock'] as num?)?.toDouble() ?? 0;
    final capacity =
        double.tryParse(set['diesel_tank_capacity_liters'] ?? '0') ?? 0;
    final percent = capacity > 0 ? stock / capacity * 100 : 100;
    return {
      'stock': stock,
      'capacity': capacity,
      'percent': percent,
      'warning': capacity > 0 && percent <= warning,
      'snoozed_until': set['diesel_warning_snoozed_until'],
    };
  }

  Future<double> dieselStock() => accounting.dieselStock();
  Future<List<Map<String, Object?>>> diesel() => db.query(
    'SELECT dm.*,b.name beneficiary_name FROM diesel_movements dm LEFT JOIN beneficiaries b ON b.id=dm.beneficiary_id ORDER BY dm.date DESC',
  );
  Future<List<Map<String, Object?>>> payments() => db.query(
    'SELECT p.*,COALESCE(b.name,COALESCE(w.name,pt.name)) party_name,pm.name method_name,c.name cashbox_name FROM payments p LEFT JOIN beneficiaries b ON b.id=p.beneficiary_id LEFT JOIN workers w ON w.id=p.worker_id LEFT JOIN partners pt ON pt.id=p.partner_id JOIN payment_methods pm ON pm.id=p.payment_method_id JOIN cashboxes c ON c.id=p.cashbox_id ORDER BY p.date DESC',
  );
  Future<List<Map<String, Object?>>> expenses() =>
      db.query('SELECT * FROM expenses ORDER BY date DESC');
  Future<List<Map<String, Object?>>> workers() => db.query(
    "SELECT w.*, COALESCE((SELECT SUM(CASE WHEN wt.type IN ${BalanceSql.workerCredit} THEN wt.amount ELSE -wt.amount END) FROM worker_transactions wt WHERE wt.worker_id=w.id),0)+w.opening_balance+w.carried_balance balance FROM workers w WHERE w.active=1 ORDER BY w.name",
  );
  Future<Map<String, Object?>> partyFinancialSummary(String kind, int id) async {
    if (kind == 'worker') {
      final r = await db.query('''
        SELECT
          COALESCE((SELECT SUM(i.minutes) FROM irrigations i WHERE i.worker_id=? AND i.status!='cancelled'),0) irrigation_minutes,
          COALESCE((SELECT SUM(i.total_amount) FROM irrigations i WHERE i.worker_id=? AND i.status!='cancelled'),0) irrigation_total,
          COALESCE((SELECT SUM(CASE WHEN wt.type IN ('accrual','salary') THEN wt.amount ELSE 0 END) FROM worker_transactions wt WHERE wt.worker_id=?),0) earnings,
          COALESCE((SELECT SUM(CASE wt.type WHEN 'payment' THEN wt.amount WHEN 'payment_reversal' THEN -wt.amount ELSE 0 END) FROM worker_transactions wt WHERE wt.worker_id=?),0) paid,
          COALESCE((SELECT SUM(CASE WHEN wt.type IN ${BalanceSql.workerCredit} THEN wt.amount ELSE -wt.amount END) FROM worker_transactions wt WHERE wt.worker_id=?),0)
            +COALESCE((SELECT opening_balance+carried_balance FROM workers WHERE id=?),0) balance''',
        args: [id,id,id,id,id,id],
      );
      return r.first;
    }
    if (kind == 'partner') {
      final r = await db.query('''
        SELECT
          COALESCE((SELECT SUM(i.minutes) FROM irrigations i WHERE i.partner_id=? AND i.status!='cancelled'),0) irrigation_minutes,
          COALESCE((SELECT SUM(i.total_amount) FROM irrigations i WHERE i.partner_id=? AND i.status!='cancelled'),0) irrigation_total,
          COALESCE((SELECT SUM(CASE WHEN pt.type IN ${BalanceSql.partnerEarnings} THEN pt.amount ELSE 0 END) FROM partner_transactions pt WHERE pt.partner_id=?),0) earnings,
          COALESCE((SELECT SUM(CASE pt.type WHEN 'payment' THEN pt.amount WHEN 'payment_reversal' THEN -pt.amount ELSE 0 END) FROM partner_transactions pt WHERE pt.partner_id=?),0) paid,
          COALESCE((SELECT SUM(CASE WHEN pt.type IN ${BalanceSql.partnerCredit} THEN pt.amount ELSE -pt.amount END) FROM partner_transactions pt WHERE pt.partner_id=?),0)
            +COALESCE((SELECT opening_balance+carried_balance FROM partners WHERE id=?),0) balance''',
        args: [id,id,id,id,id,id],
      );
      return r.first;
    }
    final r = await db.query('''
      SELECT
        COALESCE((SELECT SUM(i.minutes) FROM irrigations i WHERE i.beneficiary_id=b.id AND i.status!='cancelled'),0) irrigation_minutes,
        COALESCE((SELECT SUM(i.total_amount) FROM irrigations i WHERE i.beneficiary_id=b.id AND i.status!='cancelled'),0) irrigation_total,
        COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.beneficiary_id=b.id AND p.status='posted'),0) paid,
        (${BalanceSql.beneficiary('b')}) balance
      FROM beneficiaries b WHERE b.id=?''', args: [id]);
    return r.first;
  }

  Future<List<Map<String, Object?>>> partyIrrigations(String kind, int id) async {
    final where = switch (kind) {
      'worker' => 'i.worker_id=?',
      'partner' => 'i.partner_id=?',
      _ => 'i.beneficiary_id=?',
    };
    return db.query('''
      SELECT i.id,i.date,i.start_datetime,i.end_datetime,i.minutes,i.cloud_minutes,
             i.chargeable_minutes,i.total_amount,i.paid_amount,i.system_type,
             COALESCE(b.name,w.name,p.name) party_name,
             COALESCE(i.notes,'') notes
      FROM irrigations i
      LEFT JOIN beneficiaries b ON b.id=i.beneficiary_id
      LEFT JOIN workers w ON w.id=i.worker_id
      LEFT JOIN partners p ON p.id=i.partner_id
      WHERE $where AND i.status!='cancelled'
      ORDER BY i.start_datetime DESC''', args: [id]);
  }

  Future<List<Map<String, Object?>>> workerTransactions(int id) => db.query(
    'SELECT * FROM worker_transactions WHERE worker_id=? ORDER BY date DESC,id DESC', args: [id]);

  Future<List<Map<String, Object?>>> partnerTransactions(int id) => db.query(
    'SELECT * FROM partner_transactions WHERE partner_id=? ORDER BY date DESC,id DESC', args: [id]);

  Future<int> createWorker({
    required String name,
    required String payType,
    int fixedSalary = 0,
    int hourlyRate = 0,
    double percentageRate = 0,
    String? phone,
    String? title,
    int? userId,
  }) async {
    final id = await db.insert('workers', {
      'name': name,
      'phone': phone,
      'job_title': title,
      'pay_type': payType,
      'fixed_salary': fixedSalary,
      'hourly_rate': hourlyRate,
      'percentage_rate': percentageRate,
      'active': 1,
    });
    await db.audit(
      userId: userId,
      operation: 'create',
      table: 'workers',
      recordId: id,
      newValues: {'name': name, 'pay_type': payType},
    );
    return id;
  }

  Future<void> updateWorker(int id, Map<String,Object?> values, int? userId) async {
    final old = (await db.query('workers', where:'id=?', whereArgs:[id], limit:1)).first;
    await db.update('workers', values, 'id=?', [id]);
    await db.audit(userId:userId, operation:'update', table:'workers', recordId:id, oldValues:old, newValues:values);
  }
  Future<void> deleteWorker(int id, int? userId, String reason) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب الحذف مطلوب');
    // لا حذف لعامل له رصيد (له أو عليه): يخرج من لوحة التحكم وتبقى حركاته، فتتباعد الأرقام.
    final bal = (await accounting.workerBalance(id))['balance'] ?? 0;
    if (bal != 0) {
      throw StateError('لا يمكن حذف عامل رصيده ${AccountingCalculations.balanceLabel(bal)}؛ سوِّ حسابه أولًا');
    }
    await db.update('workers', {'active':0}, 'id=?', [id]);
    await db.audit(userId:userId, operation:'logical_delete', table:'workers', recordId:id, reason:reason);
  }

  Future<void> workerTransaction({
    required int workerId,
    required String type,
    required int amount,
    double hours = 0,
    int rateSnapshot = 0,
    double percentageSnapshot = 0,
    int? cashboxId,
    int? paymentMethodId,
    String? notes,
    int? userId,
  }) async {
    if (amount <= 0) throw ArgumentError('المبلغ يجب أن يكون أكبر من صفر');
    if (type == 'accrual' || type == 'salary')
      await accounting.createWorkerAccrual(
        workerId: workerId,
        amount: amount,
        date: AppClock.now(),
        hours: hours,
        rateSnapshot: rateSnapshot,
        percentageSnapshot: percentageSnapshot,
        userId: userId,
        memo: notes,
      );
    else if (type == 'payment') {
      final src = await accounting.paymentSource(
        paymentMethodId: paymentMethodId,
        cashboxId: cashboxId,
      );
      await accounting.payWorker(
        workerId: workerId,
        amount: amount,
        paymentMethodId: src['method']!,
        cashboxId: src['cashbox']!,
        userId: userId,
        notes: notes,
      );
    } else {
      // أي نوع آخر كان يُدخل حركة في الكشف دون قيد محاسبي، فتتباعد الكشوف عن الأستاذ.
      throw ArgumentError('نوع حركة العامل غير مدعوم: $type');
    }
  }

  Future<List<Map<String, Object?>>> partners() => db.query(
    "SELECT p.*, COALESCE((SELECT SUM(CASE WHEN pt.type IN ${BalanceSql.partnerCredit} THEN pt.amount ELSE -pt.amount END) FROM partner_transactions pt WHERE pt.partner_id=p.id),0)+p.opening_balance+p.carried_balance balance FROM partners p WHERE p.active=1 ORDER BY p.name",
  );
  Future<int> createPartner({
    required String name,
    required String mode,
    int shares = 0,
    double percentage = 0,
    String? phone,
    int? userId,
  }) async {
    final id = await db.insert('partners', {
      'station_id': 1,
      'name': name.trim(),
      'phone': phone,
      'ownership_mode': mode,
      'shares_count': shares,
      'ownership_percentage': percentage,
      'active': 1,
    });
    await db.audit(
      userId: userId,
      operation: 'create',
      table: 'partners',
      recordId: id,
      newValues: {'name': name, 'ownership_mode': mode},
    );
    return id;
  }

  Future<void> updatePartner(int id, Map<String,Object?> values, int? userId) async {
    final old = (await db.query('partners', where:'id=?', whereArgs:[id], limit:1)).first;
    await db.update('partners', values, 'id=?', [id]);
    await db.audit(userId:userId, operation:'update', table:'partners', recordId:id, oldValues:old, newValues:values);
  }
  Future<void> deletePartner(int id, int? userId, String reason) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب الحذف مطلوب');
    final bal = (await accounting.partnerBalance(id))['balance'] ?? 0;
    if (bal != 0) {
      throw StateError('لا يمكن حذف شريك رصيده ${AccountingCalculations.balanceLabel(bal)}؛ سوِّ حسابه أولًا');
    }
    await db.update('partners', {'active':0}, 'id=?', [id]);
    await db.audit(userId:userId, operation:'logical_delete', table:'partners', recordId:id, reason:reason);
  }

  Future<List<Map<String, Object?>>> paymentMethods() => db.query(
    'SELECT pm.*,c.name cashbox_name FROM payment_methods pm LEFT JOIN cashboxes c ON c.id=pm.cashbox_id WHERE pm.active=1 ORDER BY pm.name',
  );
  Future<List<Map<String, Object?>>> cashboxes() =>
      db.query('SELECT * FROM cashboxes WHERE active=1 ORDER BY name');

  /// إنشاء صندوق: الرصيد الافتتاحي يُقيَّد في الأستاذ (انظر AccountingService.createCashbox).
  Future<int> createCashbox({
    required String name,
    int openingBalance = 0,
    String currency = 'YER',
    String ledgerAccountCode = '1000',
    int? userId,
  }) => accounting.createCashbox(
    name: name,
    openingBalance: openingBalance,
    currency: currency,
    ledgerAccountCode: ledgerAccountCode,
    userId: userId,
  );

  /// تعديل اسم الصندوق فقط. الرصيد الافتتاحي والحساب لا يُعدَّلان بعد الإنشاء لأن أرصدة
  /// وقيودًا قامت عليهما؛ التصحيح يكون بتحويل أو قيد تسوية.
  Future<void> updateCashbox(int id, {required String name, int? userId}) async {
    if (name.trim().isEmpty) throw ArgumentError('اسم الصندوق مطلوب');
    final rows = await db.query('SELECT * FROM cashboxes WHERE id=?', args: [id]);
    if (rows.isEmpty) throw StateError('الصندوق غير موجود');
    await db.update('cashboxes', {'name': name.trim()}, 'id=?', [id]);
    await db.audit(
      userId: userId,
      operation: 'update',
      table: 'cashboxes',
      recordId: id,
      oldValues: {'name': rows.first['name']},
      newValues: {'name': name.trim()},
    );
  }

  /// حذف منطقي للصندوق: مرفوض إن كان رصيده غير صفر أو له طرق دفع مفعّلة، أو كان آخر صندوق مفعّل.
  Future<void> deleteCashbox(int id, int? userId, String reason) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب الحذف مطلوب');
    final rows = await db.query('SELECT * FROM cashboxes WHERE id=? AND active=1', args: [id]);
    if (rows.isEmpty) throw StateError('الصندوق غير موجود');
    final bal = (rows.first['current_balance'] as num?)?.round() ?? 0;
    if (bal != 0) {
      throw StateError('لا يمكن حذف صندوق رصيده $bal؛ حوِّل رصيده إلى صندوق آخر أولًا');
    }
    final methods = await db.query(
      'SELECT name FROM payment_methods WHERE cashbox_id=? AND active=1',
      args: [id],
    );
    if (methods.isNotEmpty) {
      throw StateError('الصندوق مرتبط بطرق دفع مفعّلة (${methods.map((m) => m['name']).join('، ')})؛ احذفها أو انقلها أولًا');
    }
    final others = await db.query('SELECT COUNT(*) n FROM cashboxes WHERE active=1 AND id<>?', args: [id]);
    if (((others.first['n'] as num?)?.toInt() ?? 0) == 0) {
      throw StateError('لا يمكن حذف آخر صندوق مفعّل');
    }
    await db.update('cashboxes', {'active': 0}, 'id=?', [id]);
    await db.audit(
      userId: userId,
      operation: 'logical_delete',
      table: 'cashboxes',
      recordId: id,
      oldValues: rows.first,
      reason: reason,
    );
  }

  Future<int> createPaymentMethod({
    required String name,
    required String type,
    int? cashboxId,
    String? accountNumber,
    String? bankName,
    int? userId,
  }) async {
    if (name.trim().isEmpty) throw ArgumentError('اسم طريقة الدفع مطلوب');
    final code = await _methodLedgerCode(type, cashboxId);
    final id = await db.insert('payment_methods', {
      'station_id': 1,
      'name': name.trim(),
      'type': type,
      'cashbox_id': cashboxId,
      'account_number': accountNumber,
      'bank_name': bankName,
      'ledger_account_code': code,
      'active': 1,
    });
    await db.audit(
      userId: userId,
      operation: 'create',
      table: 'payment_methods',
      recordId: id,
      newValues: {'name': name, 'type': type, 'cashbox_id': cashboxId},
    );
    return id;
  }

  /// حساب الأستاذ للطريقة يُورَّث من صندوقها (مصدر واحد)؛ وبلا صندوق يُشتق من نوعها.
  Future<String> _methodLedgerCode(String type, int? cashboxId) async {
    if (cashboxId != null) {
      final c = await db.query(
        'SELECT ledger_account_code FROM cashboxes WHERE id=? AND active=1',
        args: [cashboxId],
      );
      if (c.isEmpty) throw ArgumentError('الصندوق المرتبط غير موجود أو غير مفعّل');
      final code = c.first['ledger_account_code'] as String?;
      if (code != null && code.isNotEmpty) return code;
    }
    return switch (type) {
      'bank_transfer' => '1100',
      'wallet' => '1120',
      _ => '1000',
    };
  }

  Future<void> updatePaymentMethod(
    int id, {
    required String name,
    required String type,
    int? cashboxId,
    String? accountNumber,
    String? bankName,
    int? userId,
  }) async {
    if (name.trim().isEmpty) throw ArgumentError('اسم طريقة الدفع مطلوب');
    final rows = await db.query('SELECT * FROM payment_methods WHERE id=?', args: [id]);
    if (rows.isEmpty) throw StateError('طريقة الدفع غير موجودة');
    final code = await _methodLedgerCode(type, cashboxId);
    final values = {
      'name': name.trim(),
      'type': type,
      'cashbox_id': cashboxId,
      'account_number': accountNumber,
      'bank_name': bankName,
      'ledger_account_code': code,
    };
    await db.update('payment_methods', values, 'id=?', [id]);
    await db.audit(
      userId: userId,
      operation: 'update',
      table: 'payment_methods',
      recordId: id,
      oldValues: rows.first,
      newValues: values,
    );
  }

  /// حذف منطقي لطريقة دفع (الدفعات القديمة تبقى مرتبطة بها). لا تُحذف آخر طريقة مفعّلة.
  Future<void> deletePaymentMethod(int id, int? userId, String reason) async {
    if (reason.trim().isEmpty) throw ArgumentError('سبب الحذف مطلوب');
    final rows = await db.query('SELECT * FROM payment_methods WHERE id=? AND active=1', args: [id]);
    if (rows.isEmpty) throw StateError('طريقة الدفع غير موجودة');
    final others = await db.query('SELECT COUNT(*) n FROM payment_methods WHERE active=1 AND id<>?', args: [id]);
    if (((others.first['n'] as num?)?.toInt() ?? 0) == 0) {
      throw StateError('لا يمكن حذف آخر طريقة دفع مفعّلة');
    }
    await db.update('payment_methods', {'active': 0}, 'id=?', [id]);
    await db.audit(
      userId: userId,
      operation: 'logical_delete',
      table: 'payment_methods',
      recordId: id,
      oldValues: rows.first,
      reason: reason,
    );
  }

  Future<List<Map<String, Object?>>> transfers() => db.query(
    'SELECT t.*,f.name from_cashbox,tb.name to_cashbox FROM cashbox_transfers t LEFT JOIN cashboxes f ON f.id=t.from_cashbox_id LEFT JOIN cashboxes tb ON tb.id=t.to_cashbox_id ORDER BY t.date DESC',
  );
  Future<List<Map<String, Object?>>> journal({
    DateTime? from,
    DateTime? to,
    String? accountCode,
  }) async {
    final args = <Object?>[];
    var w = '1=1';
    if (from != null) {
      w += ' AND je.date>=?';
      args.add(from.toIso8601String());
    }
    if (to != null) {
      // نهاية اليوم المحدد كاملًا (كان التاريخ بمنتصف الليل يستبعد قيود ذلك اليوم).
      w += ' AND je.date<?';
      args.add(DateTime(to.year, to.month, to.day).add(const Duration(days: 1)).toIso8601String());
    }
    if (accountCode != null) {
      w += ' AND a.code=?';
      args.add(accountCode);
    }
    return db.query(
      'SELECT je.*,a.code account_code,a.name account_name,jl.debit,jl.credit,jl.beneficiary_id,jl.worker_id,jl.partner_id,jl.memo FROM journal_entries je JOIN journal_lines jl ON jl.journal_entry_id=je.id JOIN accounts a ON a.id=jl.account_id WHERE $w ORDER BY je.date,je.id,jl.id',
      args: args,
    );
  }

  Future<List<Map<String, Object?>>> ledger(
    String accountCode, {
    DateTime? from,
    DateTime? to,
  }) => journal(from: from, to: to, accountCode: accountCode);
  Future<Map<String, String>> settings() => db
      .query('SELECT key,value FROM settings')
      .then(
        (r) => {for (final x in r) x['key'] as String: x['value'] as String},
      );

  Future<Map<String, Object?>> systemConfiguration() async {
    final set = await settings();
    final configuredPumpId = int.tryParse(set['selected_pump_id'] ?? '');
    final rows = configuredPumpId == null
        ? <Map<String, Object?>>[]
        : await db.query(
            'SELECT id,name,station_id,system_type,active FROM pumps WHERE id=? AND active=1 LIMIT 1',
            args: [configuredPumpId],
          );
    if (rows.isEmpty) {
      throw StateError('المضخة المحددة في الإعدادات غير موجودة أو غير فعالة');
    }
    final pump = rows.first;
    final type = set['system_type'] ?? 'diesel';
    const allowed = {'diesel', 'solar', 'equivalent_hybrid'};
    if (!allowed.contains(type)) throw StateError('نوع المنظومة في الإعدادات غير صالح');
    if (pump['system_type'] != type) {
      // الإعداد المركزي هو المرجع؛ نصلح نسخة نوع المضخة القديمة بدل السماح بتناقض صامت.
      await db.update('pumps', {'system_type': type}, 'id=?', [pump['id']]);
      pump['system_type'] = type;
    }
    return {
      'system_type': type,
      'pump_id': pump['id'],
      'pump_name': pump['name'],
      'pump_system_type': pump['system_type'],
    };
  }

  Future<void> setSystemType(String type) async {
    const allowed = {'diesel', 'solar', 'equivalent_hybrid'};
    if (!allowed.contains(type)) throw ArgumentError('نوع المنظومة غير صالح');
    final set = await settings();
    final pumpId = int.tryParse(set['selected_pump_id'] ?? '');
    await db.transaction((tx) async {
      await tx.insert('settings', {
        'key': 'system_type',
        'value': type,
        'updated_at': AppClock.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      if (pumpId != null) {
        await tx.update(
          'pumps',
          {'system_type': type},
          where: 'id=?',
          whereArgs: [pumpId],
        );
      }
    });
  }

  /// اختيار المضخة المستخدمة: يحفظ الإعدادين ويطابق نوع المضخة بنوع المنظومة في معاملة واحدة.
  Future<void> selectPump(int pumpId) async {
    final set = await settings();
    final pump = await db.query(
      'SELECT id,name FROM pumps WHERE id=? AND active=1',
      args: [pumpId],
    );
    if (pump.isEmpty) throw ArgumentError('المضخة غير موجودة أو غير مفعّلة');
    final now = AppClock.now().toIso8601String();
    await db.transaction((tx) async {
      await tx.insert('settings', {
        'key': 'selected_pump_id',
        'value': '$pumpId',
        'updated_at': now,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      await tx.insert('settings', {
        'key': 'pump_name',
        'value': '${pump.first['name']}',
        'updated_at': now,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      await tx.update(
        'pumps',
        {'system_type': set['system_type'] ?? 'diesel'},
        where: 'id=?',
        whereArgs: [pumpId],
      );
    });
  }

  Future<void> setSetting(String key, String value) => db.insert('settings', {
    'key': key,
    'value': value,
    'updated_at': AppClock.now().toIso8601String(),
  }, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<Map<String, Object?>> dashboard() async {
    final r = await db.query(
      "SELECT (SELECT value FROM settings WHERE key='system_type' LIMIT 1) system_type,(SELECT COUNT(*) FROM beneficiaries WHERE status='active') beneficiaries,(SELECT COUNT(*) FROM queue_entries WHERE status IN ('waiting','postponed')) queue,(SELECT COUNT(*) FROM booking_requests WHERE status IN ('new','under_review')) bookings,(SELECT COUNT(*) FROM irrigation_sessions WHERE status='running') running_sessions,(SELECT COALESCE(SUM(amount),0) FROM expenses WHERE status='posted') expenses,(SELECT COALESCE(SUM(total_amount),0) FROM irrigations WHERE status!='cancelled') revenue,(SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='posted' AND beneficiary_id IS NOT NULL) paid,(SELECT COALESCE(SUM(bal),0) FROM (SELECT ${await _balanceSql()} bal FROM beneficiaries b WHERE b.status='active')) remaining,(SELECT COALESCE(SUM(total_amount),0) FROM irrigations WHERE status!='cancelled') due,(SELECT COUNT(*) FROM notifications WHERE read_at IS NULL) unread_notifications,(SELECT COALESCE(SUM(opening_balance+carried_balance),0) FROM workers WHERE active=1)+(SELECT COALESCE(SUM(CASE WHEN type IN ${BalanceSql.workerCredit} THEN amount ELSE -amount END),0) FROM worker_transactions WHERE worker_id IN (SELECT id FROM workers WHERE active=1)) worker_due",
    );
    return r.first;
  }

  Future<Map<String, Object?>> currentSession() async {
    final r = await db.query(
      "SELECT s.*,b.name beneficiary_name,p.name pump_name FROM irrigation_sessions s JOIN beneficiaries b ON b.id=s.beneficiary_id JOIN pumps p ON p.id=s.pump_id WHERE s.status='running' ORDER BY s.actual_start LIMIT 1",
    );
    return r.isEmpty ? {} : r.first;
  }

  Future<List<Map<String, Object?>>> notifications({
    int? beneficiaryId,
  }) => db.query(
    'SELECT * FROM notifications ${beneficiaryId == null ? '' : 'WHERE beneficiary_id=?'} ORDER BY created_at DESC',
    args: beneficiaryId == null ? [] : [beneficiaryId],
  );
  Future<void> notify({
    int? beneficiaryId,
    required String type,
    required String title,
    required String body,
  }) async {
    await db.insert('notifications', {
      'beneficiary_id': beneficiaryId,
      'type': type,
      'title': title,
      'body': body,
      'created_at': AppClock.now().toIso8601String(),
    });
    AppAlerts.emit(title, body);
  }
  Future<void> markNotificationRead(int id) => db.update(
    'notifications',
    {'read_at': AppClock.now().toIso8601String()},
    'id=?',
    [id],
  );
  Future<void> snoozeNotification(int id, {int minutes = 10}) => db.update(
    'notifications',
    {
      'snoozed_until': AppClock.now()
          .add(Duration(minutes: minutes))
          .toIso8601String(),
    },
    'id=?',
    [id],
  );
  Future<List<Map<String, Object?>>> needyBeneficiaries() => db.query(
    "SELECT * FROM beneficiaries WHERE is_needy=1 AND status='active' ORDER BY name",
  );

  Future<List<Map<String, Object?>>> report(
    String key, {
    DateTime? from,
    DateTime? to,
    int? beneficiaryId,
    int? workerId,
    int? partnerId,
    String? systemType,
    int? cashboxId,
    int? paymentMethodId,
    String? category,
    String? status,
  }) async {
    final args = <Object?>[];
    final currentSettings = await settings();
    final currentSystemType = currentSettings['system_type'] ?? 'diesel';
    if (key == 'diesel_inventory' && currentSystemType != 'diesel') {
      throw StateError('تقرير الديزل غير متاح لأن المنظومة الحالية ليست ديزل');
    }
    if (systemType == null) systemType = currentSystemType;
    String iw = "i.status!='cancelled'";
    if (from != null) {
      iw += ' AND i.start_datetime>=?';
      args.add(from.toIso8601String());
    }
    if (to != null) {
      iw += ' AND i.start_datetime<?';
      args.add(to.add(const Duration(days: 1)).toIso8601String());
    }
    if (beneficiaryId != null) {
      iw += ' AND i.beneficiary_id=?';
      args.add(beneficiaryId);
    }
    if (systemType != null && systemType != 'all') {
      iw += ' AND i.system_type=?';
      args.add(systemType);
    }
    switch (key) {
      case 'irrigations':
        {
          final a = <Object?>[];
          var w = "i.status!='cancelled'";
          if (from != null) { w += ' AND i.start_datetime>=?'; a.add(from.toIso8601String()); }
          if (to != null) { w += ' AND i.start_datetime<?'; a.add(to.add(const Duration(days: 1)).toIso8601String()); }
          if (beneficiaryId != null) { w += ' AND i.beneficiary_id=?'; a.add(beneficiaryId); }
          if (workerId != null) { w += ' AND i.worker_id=?'; a.add(workerId); }
          if (partnerId != null) { w += ' AND i.partner_id=?'; a.add(partnerId); }
          if (systemType != null && systemType != 'all') { w += ' AND i.system_type=?'; a.add(systemType); }
          return db.rawQuery(
            '''SELECT COALESCE(b.name,wk.name,pt.name,'غير محدد') party_name,
                      i.start_datetime,i.end_datetime,i.minutes,i.paid_amount,i.total_amount,
                      COALESCE(i.cloud_minutes,0) cloud_minutes,
                      CASE WHEN COALESCE(i.cloud_minutes,0)>0 THEN 'discounted' ELSE 'none' END cloud_status
               FROM irrigations i
               LEFT JOIN beneficiaries b ON b.id=i.beneficiary_id
               LEFT JOIN workers wk ON wk.id=i.worker_id
               LEFT JOIN partners pt ON pt.id=i.partner_id
               WHERE $w ORDER BY i.start_datetime DESC''', a);
        }
      case 'cash_flow':
        return db.query(
          "SELECT date,kind,amount,title FROM (SELECT date,'payment' kind,CASE WHEN beneficiary_id IS NULL THEN -amount ELSE amount END amount,CASE WHEN beneficiary_id IS NULL THEN 'دفع' ELSE 'قبض' END title FROM payments WHERE status='posted' UNION ALL SELECT date,'expense',-amount,title FROM expenses WHERE status='posted') ORDER BY date DESC",
        );
      case 'time_comparison':
        {
          // المقارنة الزمنية تقارن الفترات الزمنية، ولا تختزلها في نوع المنظومة الحالي.
          // إذا اختير نوع محدد يبقى كمرشح، أما "الكل" فتُظهر كل الأنواع.
          final q = "SELECT substr(i.date,1,7) month,i.system_type,SUM(i.minutes) minutes,SUM(i.chargeable_minutes) chargeable_minutes,COUNT(*) operations,SUM(i.total_amount) total FROM irrigations i WHERE $iw GROUP BY month,i.system_type ORDER BY month,i.system_type";
          return db.query(q, args: args);
        }
      case 'monthly_financial':
        return db.query(
          "SELECT substr(date,1,7) month,COALESCE((SELECT SUM(total_amount) FROM irrigations x WHERE substr(x.date,1,7)=substr(i.date,1,7) AND x.status!='cancelled'),0) income,COALESCE((SELECT SUM(amount) FROM expenses e WHERE substr(e.date,1,7)=substr(i.date,1,7) AND e.status='posted'),0) expenses FROM irrigations i WHERE $iw GROUP BY substr(date,1,7) ORDER BY month",
          args: args,
        );
      case 'income':
        return _systemReportWithOverall(
          "SELECT system_type,COUNT(*) operations,SUM(water_amount) water_income,SUM(diesel_amount) diesel_income,SUM(total_amount) total FROM irrigations WHERE $iw GROUP BY system_type",
          args,
        );
      case 'payment_methods':
        return db.query(
          "SELECT pm.name method_name,pm.type,pm.account_number,pm.bank_name,COALESCE(SUM(p.amount),0) total FROM payment_methods pm LEFT JOIN payments p ON p.payment_method_id=pm.id AND p.status='posted' GROUP BY pm.id",
        );
      case 'expenses':
        {
          final a = <Object?>[];
          var w = "status='posted'";
          if (from != null) {
            w += ' AND date>=?';
            a.add(from.toIso8601String());
          }
          if (to != null) {
            w += ' AND date<?';
            a.add(to.add(const Duration(days: 1)).toIso8601String());
          }
          if (cashboxId != null) {
            w += ' AND cashbox_id=?';
            a.add(cashboxId);
          }
          if (paymentMethodId != null) {
            w += ' AND payment_method_id=?';
            a.add(paymentMethodId);
          }
          if (category != null) {
            w += ' AND category=?';
            a.add(category);
          }
          return db.query(
            'SELECT category,COUNT(*) count,SUM(amount) total FROM expenses WHERE $w GROUP BY category ORDER BY total DESC',
            args: a,
          );
        }
      case 'cashboxes':
        return db.query(
          "SELECT c.name,SUM(CASE WHEN t.to_cashbox_id=c.id THEN t.amount ELSE 0 END) incoming,SUM(CASE WHEN t.from_cashbox_id=c.id THEN t.amount ELSE 0 END) outgoing,c.current_balance FROM cashboxes c LEFT JOIN cashbox_transfers t ON t.to_cashbox_id=c.id OR t.from_cashbox_id=c.id GROUP BY c.id",
        );
      case 'queue_bookings':
        return db.query(
          "SELECT 'queue' source,b.name,q.status,q.created_at date FROM queue_entries q JOIN beneficiaries b ON b.id=q.beneficiary_id UNION ALL SELECT 'booking',b.name,br.status,br.created_at FROM booking_requests br JOIN beneficiaries b ON b.id=br.beneficiary_id ORDER BY date DESC",
        );
      case 'payment_log':
        {
          final a = <Object?>[];
          var w = 'p.status=\'posted\'';
          if (from != null) {
            w += ' AND p.date>=?';
            a.add(from.toIso8601String());
          }
          if (to != null) {
            w += ' AND p.date<?';
            a.add(to.add(const Duration(days: 1)).toIso8601String());
          }
          if (cashboxId != null) {
            w += ' AND p.cashbox_id=?';
            a.add(cashboxId);
          }
          if (paymentMethodId != null) {
            w += ' AND p.payment_method_id=?';
            a.add(paymentMethodId);
          }
          return db.query(
            'SELECT p.*,COALESCE(b.name,COALESCE(w.name,pt.name)) party_name,pm.name method_name,c.name cashbox_name FROM payments p LEFT JOIN beneficiaries b ON b.id=p.beneficiary_id LEFT JOIN workers w ON w.id=p.worker_id LEFT JOIN partners pt ON pt.id=p.partner_id JOIN payment_methods pm ON pm.id=p.payment_method_id JOIN cashboxes c ON c.id=p.cashbox_id WHERE $w ORDER BY p.date DESC',
            args: a,
          );
        }
      case 'beneficiary_statement':
        return beneficiaryId == null
            ? <Map<String, Object?>>[]
            : await beneficiaryStatement(beneficiaryId, from: from, to: to);
      case 'beneficiary_detailed':
        return beneficiaryId == null
            ? <Map<String, Object?>>[]
            : await beneficiaryStatement(beneficiaryId, from: from, to: to);
      case 'beneficiary_stats':
        return db.query(
          "SELECT b.id,b.name,COUNT(i.id) irrigations,COALESCE(SUM(i.minutes),0) minutes,COALESCE(SUM(i.total_amount),0) total FROM beneficiaries b LEFT JOIN irrigations i ON i.beneficiary_id=b.id AND i.status!='cancelled' GROUP BY b.id ORDER BY total DESC",
        );
      case 'needy':
        return db.query(
          "SELECT b.id,b.name,b.phone,${await _balanceSql()} balance FROM beneficiaries b WHERE b.is_needy=1 AND b.status='active' ORDER BY b.name",
        );
      case 'diesel_inventory':
        return diesel();
      case 'activity_overview':
        return _systemReportWithOverall(
          "SELECT system_type,COUNT(*) operations,SUM(minutes) minutes,SUM(total_amount) total FROM irrigations WHERE $iw GROUP BY system_type",
          args,
        );
      case 'oil_status':
        return db.query(
          "SELECT category,SUM(amount) total FROM expenses WHERE status='posted' AND category IN ('oil','grease') GROUP BY category",
        );
      case 'debts':
        return db.query(
          "SELECT b.id,b.name,${await _balanceSql()} balance FROM beneficiaries b WHERE b.status='active' ORDER BY balance DESC",
        );
      case 'beneficiary_list':
        return beneficiaries();
      case 'revenue_comparison':
        return db.query(
          "SELECT substr(date,1,7) month,system_type,SUM(total_amount) total FROM irrigations WHERE $iw GROUP BY month,system_type ORDER BY month",
          args: args,
        );
      case 'system_comparison':
        return _systemReportWithOverall(
          "SELECT system_type,COUNT(*) operations,SUM(minutes) minutes,SUM(total_amount) total,SUM(diesel_amount) diesel_cost FROM irrigations WHERE $iw GROUP BY system_type",
          args,
        );
      case 'journal':
        return journal(from: from, to: to);
      case 'ledger':
        return journal(from: from, to: to);
      case 'worker_transactions':
        {
          final a = <Object?>[];
          var w = '1=1';
          if (workerId != null) {
            w += ' AND wt.worker_id=?';
            a.add(workerId);
          }
          if (from != null) {
            w += ' AND wt.date>=?';
            a.add(from.toIso8601String());
          }
          if (to != null) {
            w += ' AND wt.date<?';
            a.add(to.add(const Duration(days: 1)).toIso8601String());
          }
          return db.query(
            "SELECT wt.*,wt.notes description,w.name, (SELECT COALESCE(SUM(CASE WHEN h.type IN ${BalanceSql.workerCredit} THEN h.amount ELSE -h.amount END),0) FROM worker_transactions h WHERE h.worker_id=wt.worker_id AND (h.date<wt.date OR (h.date=wt.date AND h.id<=wt.id)))+w.opening_balance+w.carried_balance balance FROM worker_transactions wt JOIN workers w ON w.id=wt.worker_id WHERE $w ORDER BY wt.date DESC,wt.id DESC",
            args: a,
          );
        }
      case 'partner_accounts':
        {
          final a = <Object?>[];
          var w = '1=1';
          if (partnerId != null) {
            w += ' AND pt.partner_id=?';
            a.add(partnerId);
          }
          if (from != null) {
            w += ' AND pt.date>=?';
            a.add(from.toIso8601String());
          }
          if (to != null) {
            w += ' AND pt.date<?';
            a.add(to.add(const Duration(days: 1)).toIso8601String());
          }
          return db.query(
            "SELECT pt.*,pt.notes description,p.name, (SELECT COALESCE(SUM(CASE WHEN h.type IN ${BalanceSql.partnerCredit} THEN h.amount ELSE -h.amount END),0) FROM partner_transactions h WHERE h.partner_id=pt.partner_id AND (h.date<pt.date OR (h.date=pt.date AND h.id<=pt.id)))+p.opening_balance+p.carried_balance balance FROM partner_transactions pt JOIN partners p ON p.id=pt.partner_id WHERE $w ORDER BY pt.date DESC,pt.id DESC",
            args: a,
          );
        }
      default:
        return irrigations(
          from: from,
          to: to,
          beneficiaryId: beneficiaryId,
          systemType: systemType,
        );
    }
  }

  Future<List<Map<String, Object?>>> _systemReportWithOverall(
    String sql,
    List<Object?> args,
  ) async {
    final rows = await db.query(sql, args: args);
    if (rows.isEmpty) return rows;
    int sumInt(String key) =>
        rows.fold<int>(0, (s, r) => s + ((r[key] as num?)?.round() ?? 0));
    final overall = <String, Object?>{'system_type': 'الإجمالي العام'};
    for (final key in [
      'minutes',
      'chargeable_minutes',
      'operations',
      'water_income',
      'diesel_income',
      'total',
      'diesel_cost',
    ]) {
      if (rows.first.containsKey(key)) overall[key] = sumInt(key);
    }
    return [...rows, overall];
  }

  Future<String> _balanceSql() => Future.value(BalanceSql.beneficiary('b'));
}
