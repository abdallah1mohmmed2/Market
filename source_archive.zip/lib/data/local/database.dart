import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:sqflite_common_ffi_web/sqflite_ffi_web.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._();
  AppDatabase._();
  Database? _db;
  Future<Database> get db async {
    if (_db != null) return _db!;
    if (kIsWeb) {
      databaseFactory = databaseFactoryFfiWeb;
    } else if (defaultTargetPlatform == TargetPlatform.windows ||
        defaultTargetPlatform == TargetPlatform.linux ||
        defaultTargetPlatform == TargetPlatform.macOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'saqia_station_v2.db');
    _db = await openDatabase(
      path,
      version: 12,
      // المفاتيح الأجنبية تُعطَّل أثناء الإنشاء/الترقية لأن SQLite لا يسمح بتغيير
      // PRAGMA foreign_keys داخل معاملة الترقية، وتُفعَّل في onOpen بعد انتهائها.
      onConfigure: (d) async => d.execute('PRAGMA foreign_keys=OFF'),
      onCreate: (d, v) async => _create(d),
      onUpgrade: (d, oldV, newV) async => _upgrade(d, oldV, newV),
      onOpen: (d) async => d.execute('PRAGMA foreign_keys=ON'),
    );
    return _db!;
  }

  Future<void> _create(Database d) async {
    final sql = await rootBundle.loadString('assets/db/001_initial.sql');
    for (final statement in sql.split(';')) {
      final s = statement.trim();
      if (s.isNotEmpty) await d.execute(s);
    }
    await _createHelpers(d);
    await _seed(d);
  }

  Future<void> _upgrade(Database d, int oldV, int newV) async {
    await _createHelpers(d);
    if (oldV < 2) {
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_sessions_status ON irrigation_sessions(status)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_bookings_status ON booking_requests(status)',
      );
    }
    if (oldV < 3)
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_sync_status ON sync_queue(status)',
      );
    if (oldV < 4) {
      await d.execute(
        'CREATE TABLE IF NOT EXISTS beneficiary_auth_codes (id INTEGER PRIMARY KEY, beneficiary_id INTEGER NOT NULL REFERENCES beneficiaries(id), code_hash TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT, attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)',
      );
      await d.execute(
        'CREATE TABLE IF NOT EXISTS period_closures (id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, closed_at TEXT NOT NULL, closed_by INTEGER NOT NULL, opening_transfer INTEGER NOT NULL DEFAULT 0, notes TEXT)',
      );
      await d.execute(
        'CREATE TABLE IF NOT EXISTS beneficiary_sessions (id INTEGER PRIMARY KEY, beneficiary_id INTEGER NOT NULL REFERENCES beneficiaries(id), token_hash TEXT UNIQUE NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, revoked_at TEXT)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_beneficiary_sessions_token ON beneficiary_sessions(token_hash)',
      );
    }
    if (oldV < 5) {
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_irrigations_status ON irrigations(status)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_payments_beneficiary ON payments(beneficiary_id,date)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_diesel_beneficiary ON diesel_movements(beneficiary_id,date)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_journal_lines_account ON journal_lines(account_id,journal_entry_id)',
      );
    }
    if (oldV < 6) {
      await d.execute(
        'ALTER TABLE payment_methods ADD COLUMN ledger_account_code TEXT',
      );
      await d.execute(
        "UPDATE payment_methods SET ledger_account_code=CASE type WHEN 'cash' THEN '1000' WHEN 'bank_transfer' THEN '1100' WHEN 'wallet' THEN '1120' ELSE '1000' END WHERE ledger_account_code IS NULL",
      );
      await d.execute(
        "INSERT OR IGNORE INTO accounts(id,code,name,type) VALUES(17,'1120','المحافظ الإلكترونية','asset')",
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(date)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date)',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_diesel_date ON diesel_movements(date)',
      );
    }
    if (oldV < 7) {
      await d.execute(
        'ALTER TABLE notifications ADD COLUMN snoozed_until TEXT',
      );
      await d.execute(
        'CREATE INDEX IF NOT EXISTS idx_notifications_beneficiary ON notifications(beneficiary_id,created_at)',
      );
    }
    if (oldV < 8) {
      for (final table in [
        'beneficiaries',
        'partners',
        'workers',
        'cashboxes',
        'payment_methods',
      ]) {
        try {
          await d.execute(
            'ALTER TABLE $table ADD COLUMN station_id INTEGER NOT NULL DEFAULT 1 REFERENCES stations(id)',
          );
        } catch (_) {}
        await d.execute(
          'CREATE INDEX IF NOT EXISTS idx_${table}_station ON $table(station_id)',
        );
      }
    }
    if (oldV < 9) {
      // إصلاح قواعد البيانات المنشأة بإصدارات أقدم: بعض الأعمدة كانت موجودة في المخطط الجديد
      // لكنها لم تكن تضاف عند الترقية، مما كان يؤدي إلى خطأ carried_diesel_liters.
      for (final item in [
        ['beneficiaries', 'opening_diesel_liters', 'REAL NOT NULL DEFAULT 0'],
        ['beneficiaries', 'carried_diesel_liters', 'REAL NOT NULL DEFAULT 0'],
        ['cashboxes', 'station_id', 'INTEGER NOT NULL DEFAULT 1 REFERENCES stations(id)'],
        ['payment_methods', 'station_id', 'INTEGER NOT NULL DEFAULT 1 REFERENCES stations(id)'],
        ['partners', 'station_id', 'INTEGER NOT NULL DEFAULT 1 REFERENCES stations(id)'],
        ['workers', 'station_id', 'INTEGER NOT NULL DEFAULT 1 REFERENCES stations(id)'],
      ]) {
        try {
          final info = await d.rawQuery("PRAGMA table_info(${item[0]})");
          final exists = info.any((x) => x['name'] == item[1]);
          if (!exists) await d.execute("ALTER TABLE ${item[0]} ADD COLUMN ${item[1]} ${item[2]}");
        } catch (_) {}
      }
      await d.insert('settings', {
        'key': 'selected_pump_id',
        'value': '1',
        'updated_at': DateTime.now().toIso8601String(),
      }, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    if (oldV < 10) {
      // إضافة صاحب حساب السقاية للعامل أو الشريك مع الحفاظ على السجلات القديمة.
      // نبني الجدول الجديد باسم مؤقت ثم نحذف القديم ونعيد التسمية؛ إعادة تسمية الجدول القديم
      // كانت تُحوّل مراجع المفاتيح الأجنبية في الجداول التابعة إلى اسم محذوف.
      // المفاتيح الأجنبية معطّلة هنا (انظر onConfigure) فلا تُفعَّل حذوفات ضمنية عند DROP.
      await d.execute('''CREATE TABLE irrigations_new (id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL REFERENCES stations(id), pump_id INTEGER NOT NULL REFERENCES pumps(id), beneficiary_id INTEGER REFERENCES beneficiaries(id), worker_id INTEGER REFERENCES workers(id), partner_id INTEGER REFERENCES partners(id), party_type TEXT NOT NULL DEFAULT 'beneficiary' CHECK(party_type IN ('beneficiary','worker','partner')), booking_id INTEGER REFERENCES booking_requests(id), queue_entry_id INTEGER REFERENCES queue_entries(id), session_id INTEGER REFERENCES irrigation_sessions(id), date TEXT NOT NULL, start_datetime TEXT NOT NULL, end_datetime TEXT NOT NULL, minutes INTEGER NOT NULL, system_type TEXT NOT NULL, water_hourly_rate_snapshot INTEGER NOT NULL DEFAULT 0, diesel_liters_per_hour_snapshot REAL NOT NULL DEFAULT 0, diesel_price_snapshot INTEGER NOT NULL DEFAULT 0, solar_hourly_rate_snapshot INTEGER NOT NULL DEFAULT 0, third_type_hourly_rate_snapshot INTEGER NOT NULL DEFAULT 0, cloud_minutes INTEGER NOT NULL DEFAULT 0, chargeable_minutes INTEGER NOT NULL, water_amount INTEGER NOT NULL DEFAULT 0, diesel_amount INTEGER NOT NULL DEFAULT 0, total_amount INTEGER NOT NULL DEFAULT 0, paid_amount INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, override_waiting_period INTEGER NOT NULL DEFAULT 0, override_reason TEXT, notes TEXT, created_by INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''');
      await d.execute('''INSERT INTO irrigations_new (id,station_id,pump_id,beneficiary_id,booking_id,queue_entry_id,session_id,date,start_datetime,end_datetime,minutes,system_type,water_hourly_rate_snapshot,diesel_liters_per_hour_snapshot,diesel_price_snapshot,solar_hourly_rate_snapshot,third_type_hourly_rate_snapshot,cloud_minutes,chargeable_minutes,water_amount,diesel_amount,total_amount,paid_amount,status,override_waiting_period,override_reason,notes,created_by,created_at,updated_at) SELECT id,station_id,pump_id,beneficiary_id,booking_id,queue_entry_id,session_id,date,start_datetime,end_datetime,minutes,system_type,water_hourly_rate_snapshot,diesel_liters_per_hour_snapshot,diesel_price_snapshot,solar_hourly_rate_snapshot,third_type_hourly_rate_snapshot,cloud_minutes,chargeable_minutes,water_amount,diesel_amount,total_amount,paid_amount,status,override_waiting_period,override_reason,notes,created_by,created_at,updated_at FROM irrigations''');
      await d.execute('DROP TABLE irrigations');
      await d.execute('ALTER TABLE irrigations_new RENAME TO irrigations');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_irrigations_beneficiary_date ON irrigations(beneficiary_id,date)');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_irrigations_pump_time ON irrigations(pump_id,start_datetime,end_datetime)');
    }
    if (oldV < 11) {
      await d.execute('''CREATE TABLE IF NOT EXISTS cloud_periods (id INTEGER PRIMARY KEY, irrigation_id INTEGER NOT NULL REFERENCES irrigations(id) ON DELETE CASCADE, start_datetime TEXT NOT NULL, end_datetime TEXT NOT NULL, minutes INTEGER NOT NULL, created_at TEXT NOT NULL)''');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_cloud_periods_irrigation ON cloud_periods(irrigation_id,start_datetime,end_datetime)');
    }
    if (oldV < 12) {
      // إصلاح قواعد رُقّيت سابقًا من إصدار أقدم من 10 بالتسلسل المعطوب، حيث بقيت مراجع
      // المفاتيح الأجنبية تشير إلى irrigations_old_v10 المحذوف فتفشل الإدخالات في الجداول التابعة.
      try {
        final bad = await d.rawQuery(
            "SELECT name FROM sqlite_master WHERE sql LIKE '%irrigations_old_v10%'");
        if (bad.isNotEmpty) {
          final sv = Sqflite.firstIntValue(await d.rawQuery('PRAGMA schema_version')) ?? 0;
          await d.execute('PRAGMA writable_schema=ON');
          await d.execute(
              "UPDATE sqlite_master SET sql=replace(replace(sql,'\"irrigations_old_v10\"','irrigations'),'irrigations_old_v10','irrigations') WHERE sql LIKE '%irrigations_old_v10%'");
          await d.execute('PRAGMA schema_version=${sv + 1}');
          await d.execute('PRAGMA writable_schema=OFF');
        }
      } catch (_) {
        // لا نمنع فتح التطبيق إن لم يسمح النظام بتعديل المخطط؛ تبقى القاعدة كما هي.
      }
    }
  }

  Future<void> _createHelpers(Database d) async {
    await d.execute(
      'CREATE TABLE IF NOT EXISTS app_users (id INTEGER PRIMARY KEY, station_id INTEGER, name TEXT NOT NULL, phone TEXT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS notification_templates (key TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, updated_at TEXT NOT NULL)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS report_runs (id INTEGER PRIMARY KEY, report_key TEXT NOT NULL, filters_json TEXT NOT NULL, generated_at TEXT NOT NULL, row_count INTEGER NOT NULL DEFAULT 0, duration_ms INTEGER NOT NULL DEFAULT 0)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS performance_metrics (id INTEGER PRIMARY KEY, screen TEXT NOT NULL, opened_at TEXT NOT NULL, open_ms INTEGER NOT NULL, query_ms INTEGER NOT NULL, pdf_ms INTEGER NOT NULL DEFAULT 0)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS period_closures (id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, closed_at TEXT NOT NULL, closed_by INTEGER NOT NULL, opening_transfer INTEGER NOT NULL DEFAULT 0, notes TEXT)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS beneficiary_auth_codes (id INTEGER PRIMARY KEY, beneficiary_id INTEGER NOT NULL REFERENCES beneficiaries(id), code_hash TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT, attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS period_closures (id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, closed_at TEXT NOT NULL, closed_by INTEGER NOT NULL, opening_transfer INTEGER NOT NULL DEFAULT 0, notes TEXT)',
    );
    await d.execute(
      'CREATE TABLE IF NOT EXISTS beneficiary_sessions (id INTEGER PRIMARY KEY, beneficiary_id INTEGER NOT NULL REFERENCES beneficiaries(id), token_hash TEXT UNIQUE NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, revoked_at TEXT)',
    );
  }

  Future<void> _seed(Database d) async {
    final now = DateTime.now().toIso8601String();
    if ((await d.query('stations')).isEmpty)
      await d.insert('stations', {
        'id': 1,
        'name': 'محطة ساقية',
        'address': '',
        'phone': '',
        'active': 1,
        'created_at': now,
        'updated_at': now,
      });
    if ((await d.query('pumps')).isEmpty)
      await d.insert('pumps', {
        'id': 1,
        'station_id': 1,
        'name': 'المضخة الرئيسية',
        'system_type': 'diesel',
        'active': 1,
      });
    if ((await d.query('accounts')).isEmpty) {
      final accounts = [
        ['1000', 'الصندوق', 'asset'],
        ['1100', 'البنك والتحويلات', 'asset'],
        ['1200', 'ذمم المستفيدين', 'asset'],
        ['1300', 'مخزون الديزل', 'asset'],
        ['1400', 'سلف الديزل', 'asset'],
        ['2100', 'مستحقات العمال', 'liability'],
        ['2200', 'مستحقات الشركاء', 'liability'],
        ['4000', 'إيرادات السقي', 'revenue'],
        ['4010', 'إيرادات الديزل', 'revenue'],
        ['5000', 'مصروف العمال', 'expense'],
        ['5010', 'مصروف الوقود', 'expense'],
        ['5020', 'مصروف الزيت', 'expense'],
        ['5030', 'مصروف الصيانة', 'expense'],
        ['3000', 'الأرصدة الافتتاحية', 'equity'],
        ['3100', 'الأرصدة المرحلة', 'equity'],
        ['3990', 'الفروقات والتصحيحات', 'equity'],
        ['1120', 'المحافظ الإلكترونية', 'asset'],
      ];
      for (var i = 0; i < accounts.length; i++)
        await d.insert('accounts', {
          'id': i + 1,
          'code': accounts[i][0],
          'name': accounts[i][1],
          'type': accounts[i][2],
        });
    }
    if ((await d.query('cashboxes')).isEmpty)
      await d.insert('cashboxes', {
        'id': 1,
        'station_id': 1,
        'name': 'الصندوق الرئيسي',
        'opening_balance': 0,
        'current_balance': 0,
        'currency': 'YER',
        'active': 1,
      });
    if ((await d.query('payment_methods')).isEmpty)
      await d.insert('payment_methods', {
        'id': 1,
        'station_id': 1,
        'name': 'نقدي',
        'type': 'cash',
        'cashbox_id': 1,
        'ledger_account_code': '1000',
        'active': 1,
      });
    await d.rawUpdate(
      "UPDATE payment_methods SET ledger_account_code=CASE type WHEN 'cash' THEN '1000' WHEN 'bank_transfer' THEN '1100' WHEN 'wallet' THEN '1120' ELSE COALESCE(ledger_account_code,'1000') END WHERE ledger_account_code IS NULL",
    );
    final defaults = {
      'station_name': 'محطة ساقية',
      'pump_name': 'المضخة الأولى',
      'selected_pump_id': '1',
      'address': '',
      'phone': '',
      'currency': 'ريال يمني',
      'timezone': 'Asia/Aden',
      'week_start': 'saturday',
      'financial_year_start': '01-01',
      'app_name': 'ساقية لإدارة محطة ضخ مياه الري',
      'system_type': 'diesel',
      'queue_type': 'circular',
      'time_source': 'device',
      'min_wait_days': '3',
      'manager_override_required': 'true',
      'absence_policy': 'keep_order',
      'allow_midnight_crossing': 'false',
      'diesel_warning_percent': '20',
      'diesel_warning_snoozed_until': '',
      'diesel_tank_capacity_liters': '0',
      'diesel_snooze_minutes': '10',
      'pdf_rows': '30',
      'solar_hourly_rate': '0',
      'diesel_hourly_water_rate': '0',
      'diesel_liters_per_hour': '0',
      'diesel_price_per_liter': '0',
      'third_type_hourly_rate': '0',
      'rounding': 'nearest',
      'partial_hour': 'true',
      'diesel_delivery_financial_credit': 'false',
      'sound_notifications': 'true',
      'popup_notifications': 'true',
      'reduced_motion': 'false',
      'notification_appointment_title': 'موعد السقي',
      'notification_appointment_body': 'تم تحديد موعد السقي: {date}',
      'notification_payment_title': 'تسجيل دفعة',
      'notification_payment_body': 'تم تسجيل دفعة بمبلغ {amount} ريال',
      'notification_balance_title': 'تحديث الرصيد',
      'notification_balance_body': 'الرصيد الحالي: {balance}',
    };
    for (final e in defaults.entries)
      await d.insert('settings', {
        'key': e.key,
        'value': e.value,
        'updated_at': now,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    if ((await d.query('app_users')).isEmpty)
      await d.insert('app_users', {
        'id': 1,
        'station_id': 1,
        'name': 'مدير النظام',
        'phone': '',
        'username': 'admin',
        'password_hash':
            '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',
        'role': 'manager',
        'active': 1,
        'created_at': now,
      });
  }

  /// Unified query API: accepts either raw SELECT/CTE SQL or a table name with
  /// sqflite-style filters. This keeps the UI/repository layer on one contract.
  Future<List<Map<String, Object?>>> query(
    String source, {
    List<Object?> args = const [],
    List<String>? columns,
    String? where,
    List<Object?>? whereArgs,
    String? orderBy,
    int? limit,
    int? offset,
  }) async {
    final value = source.trimLeft().toLowerCase();
    if (value.startsWith('select ') ||
        value.startsWith('with ') ||
        value.startsWith('pragma ')) {
      return (await db).rawQuery(source, args);
    }
    return (await db).query(
      source,
      columns: columns,
      where: where,
      whereArgs: whereArgs,
      orderBy: orderBy,
      limit: limit,
      offset: offset,
    );
  }

  Future<int> insert(
    String table,
    Map<String, Object?> values, {
    ConflictAlgorithm? conflictAlgorithm,
  }) async =>
      (await db).insert(table, values, conflictAlgorithm: conflictAlgorithm);
  Future<int> update(
    String table,
    Map<String, Object?> values,
    String where,
    List<Object?> args,
  ) async => (await db).update(table, values, where: where, whereArgs: args);
  Future<int> delete(String table, String where, List<Object?> args) async =>
      (await db).delete(table, where: where, whereArgs: args);
  Future<T> transaction<T>(Future<T> Function(Transaction tx) action) async =>
      (await db).transaction(action);
  Future<void> close() async {
    final d = _db;
    _db = null;
    if (d != null) await d.close();
  }

  Future<void> auditTx(
    Transaction tx, {
    int? userId,
    required String operation,
    required String table,
    int? recordId,
    Object? oldValues,
    Object? newValues,
    String? reason,
  }) async {
    await tx.insert('audit_logs', {
      'user_id': userId,
      'operation': operation,
      'table_name': table,
      'record_id': recordId,
      'old_values': oldValues == null ? null : jsonEncode(oldValues),
      'new_values': newValues == null ? null : jsonEncode(newValues),
      'reason': reason,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> audit({
    int? userId,
    required String operation,
    required String table,
    int? recordId,
    Object? oldValues,
    Object? newValues,
    String? reason,
  }) async {
    await insert('audit_logs', {
      'user_id': userId,
      'operation': operation,
      'table_name': table,
      'record_id': recordId,
      'old_values': oldValues == null ? null : jsonEncode(oldValues),
      'new_values': newValues == null ? null : jsonEncode(newValues),
      'reason': reason,
      'created_at': DateTime.now().toIso8601String(),
    });
  }
}
